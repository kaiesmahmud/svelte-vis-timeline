<script>
</script>

<div class="flex items-center justify-center">
    <main class="bg-white border rounded-lg h-full flex flex-col gap-5 p-10">
        <p>
            Nested Tree folder: 
            <a
                href="https://visjs.github.io/vis-timeline/examples/timeline/groups/nestedThreeLevels.html"
                >https://visjs.github.io/vis-timeline/examples/timeline/groups/nestedThreeLevels.html</a
            >
        </p>
        <p>
            Moving timebar play head:
            <a
                href="https://visjs.github.io/vis-timeline/examples/timeline/editing/updateDataOnEvent.html"
                >https://visjs.github.io/vis-timeline/examples/timeline/editing/updateDataOnEvent.html</a
            >
        </p>
        <p>
            Stacking or No Stacking of subgroups:
            <a
                href="https://visjs.github.io/vis-timeline/examples/timeline/groups/subgroups.html"
                >https://visjs.github.io/vis-timeline/examples/timeline/groups/subgroups.html</a
            >
        </p>
        <p>
            Serialization:
            <a
                href="https://visjs.github.io/vis-timeline/examples/timeline/dataHandling/dataSerialization.html"
                >https://visjs.github.io/vis-timeline/examples/timeline/dataHandling/dataSerialization.html
            </a>
        </p>
        <p>
            VISJS ecosystem:
            <a href="https://github.com/visjs/awesome-visjs"
                >https://github.com/visjs/awesome-visjs</a
            >
        </p>
    </main>
</div>

<style>
    a {
        @apply hover:underline p-5;
    }
</style>
